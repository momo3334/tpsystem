//#########################################################
//#
//# Titre : 	Utilitaires Liste Chainee et CVS LINUX Automne 21
//#				SIF-1015 - Système d'exploitation
//#				Université du Québec à Trois-Rivières
//#
//# Auteur : 	Francois Meunier
//#	Date :		Septembre 2022
//#
//# Langage : 	ANSI C on LINUX
//#
//#######################################

#include "gestionListeChaineeVMS.h"
#include "gestionVMS.h"

// Pointeur de tête de liste
extern struct noeudVM *head;
// Pointeur de queue de liste pour ajout rapide
extern struct noeudVM *queue;
// nombre de VM actives
extern int nbVM;
// Compteur gardant en mémoire le nombre courant de thread de l'application.
extern int nbThreads;

// Compteur gardant en mémoire le nombre courant de remove de l'application.
extern int nbRemove;

// Mutex empechant l'accès concurrentiel au différents noeuds de la liste chaînée
extern pthread_mutex_t mut_listeHead, mut_listeQueue, mut_listeNbVM;

// Mutex permettant de gerer l'accès au nombre de thread courant de l'application.
extern sem_t sem_nbThreads;

// Mutex permettant de gerer l'accès au nombre de remove en attente courant de l'application.
extern pthread_mutex_t mut_nbRemove;

// Mutex permettant de gerer l'accès à la console pour tous les threads de l'application.
extern sem_t sem_consoleAccess;

//#######################################
//# Recherche un item dans la liste chaînée
//# ENTREE: Numéro de la ligne
//# RETOUR:	Un pointeur vers l'item recherché
//# 		Retourne NULL dans le cas où l'item
//#			est introuvable
//#
struct noeudVM *findItem(const int no)
{
	// Vérification si la liste est vide.
	if (isListEmpty() != 0)
	{
		return NULL;
	}

	// On barre le mutex de la head de la liste.
	pthread_mutex_lock(&mut_listeHead);

	// Pointeur de navigation
	struct noeudVM *ptr = head;

	// On débarre le mutex de la head de la liste.
	pthread_mutex_unlock(&mut_listeHead);

	// On barre le mutex du noeud(head de la liste).
	pthread_mutex_lock(&(ptr->mut_noeudVM));

	if (ptr->VM.noVM == no) // premier noeudVM
	{
		return ptr;
	}

	// Tant qu'un item suivant existe
	while (ptr->suivant != NULL)
	{
		struct noeudVM *ancienNoeud = ptr;
		// On barre le prochain noeudVM.
		pthread_mutex_lock(&(ptr->suivant->mut_noeudVM));

		// Déplacement du pointeur de navigation
		ptr = ptr->suivant;

		// On debarre l'ancien noeud.
		pthread_mutex_unlock(&(ancienNoeud->mut_noeudVM));
		// Est-ce l'item recherché?
		if (ptr->VM.noVM == no)
		{
			return ptr;
		}
	}

	// On debarre le mutex du noeud.
	pthread_mutex_unlock(&(ptr->mut_noeudVM));
	// On retourne un pointeur NULL
	return NULL;
}

//#######################################
//#
//# Recherche le PRÉDÉCESSEUR d'un item dans la liste chaînée
//# ENTREE: Numéro de la ligne a supprimer
//# RETOUR:	Le pointeur vers le prédécesseur est retourné
//# 		Retourne NULL dans le cas où l'item est introuvable
//#
struct noeudVM *findPrev(const int no)
{
	// Vérification si la liste est vide.
	if (isListEmpty() != 0)
	{
		return NULL;
	}

	// On barre le mutex de la head de la liste.
	pthread_mutex_lock(&mut_listeHead);

	// Pointeur de navigation
	struct noeudVM *ptr = head;

	// On debarre le mutex de la head de la liste.
	pthread_mutex_unlock(&mut_listeHead);

	// On barre le mutex du noeud(head de la liste).
	pthread_mutex_lock(&(ptr->mut_noeudVM));

	// Tant qu'un item suivant existe
	while (ptr->suivant != NULL)
	{
		struct noeudVM *ancienNoeud = ptr;
		// On barre le prochain noeudVM.
		pthread_mutex_lock(&(ptr->suivant->mut_noeudVM));

		// Est-ce le prédécesseur de l'item recherché?
		if (ptr->suivant->VM.noVM == no)
		{
			// On debarre l'ancien noeud.
			pthread_mutex_unlock(&(ancienNoeud->mut_noeudVM));

			// On retourne un pointeur sur l'item précédent
			return ptr;
		}
		// Déplacement du pointeur de navigation
		ptr = ptr->suivant;
		// On debarre l'ancien noeud.
		pthread_mutex_unlock(&(ancienNoeud->mut_noeudVM));
	}

	// On debarre le mutex du noeud.
	pthread_mutex_unlock(&(ptr->mut_noeudVM));
	// On retourne un pointeur NULL
	return NULL;
}

//#####################################################
//# Ajoute un item a la fin de la liste chaînée de VM
//# ENTREE:
//#	RETOUR:
void addItem()
{
	nbThreads++; // Incrémentation du nombre de threads courant de l'application.
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	// Création de l'enregistrement en mémoire
	struct noeudVM *ni = (struct noeudVM *)malloc(sizeof(struct noeudVM));
	// printf("\n noVM=%d busy=%d adr ni=%p", ni->VM.noVM, ni->VM.busy, ni);
	// printf("\n noVM=%d busy=%d adrQ deb=%p", ni->VM.noVM, ni->VM.busy,queue);

	// Affectation des valeurs des champs
	ni->VM.noVM = ++nbVM;
	// printf("\n noVM=%d", ni->VM.noVM);
	ni->VM.busy = 0;
	// printf("\n busy=%d", ni->VM.busy);
	ni->VM.ptrDebutVM = (unsigned short *)malloc(sizeof(unsigned short) * 65536);

	// printf("\n noVM=%d busy=%d adrptr VM=%p", ni->VM.noVM, ni->VM.busy, ni->VM.ptrDebutVM);
	// printf("\n noVM=%d busy=%d adrQ=%p", ni->VM.noVM, ni->VM.busy, queue);

	// Initialisation du mutex empechant l'accès concurrentiel au noeud.
	pthread_mutex_init(&ni->mut_noeudVM, NULL);

	// Vérification si la liste est vide.
	if (isListEmpty() != 0)
	{
		// On barre le mutex de la liste head et queue car nous allons accéder aux variables critiques.
		pthread_mutex_lock(&mut_listeHead);
		pthread_mutex_lock(&mut_listeQueue);
		ni->suivant = NULL;
		queue = head = ni;

		// On débarre le mutex de la liste head et queue car nous avons terminé l'accès aux variables critiques.
		pthread_mutex_unlock(&mut_listeHead);
		pthread_mutex_unlock(&mut_listeQueue);

		// Barre le mutex gerant le nombre de threads.
		sem_wait(&sem_nbThreads);
		nbThreads--;
		// Debarre le mutex gerant le nombre de threads.
		sem_post(&sem_nbThreads);
		pthread_exit(0);
	}

	// On barre le mutex du noeud de queue.
	pthread_mutex_lock(&queue->mut_noeudVM);
	pthread_mutex_lock(&mut_listeQueue);

	// On débarre le mutex de la liste head car nous avons terminé l'accès aux variables critiques.
	pthread_mutex_unlock(&mut_listeHead);

	struct noeudVM *tptr = queue;
	ni->suivant = NULL;
	queue = ni;
	// printf("\n noVM=%d busy=%d adrQ=%p", ni->VM.noVM, ni->VM.busy, queue);
	tptr->suivant = ni;
	// printf("\n noVM=%d busy=%d adr Queue=%p", ni->VM.noVM, ni->VM.busy,queue);

	// On débarre le mutex de la liste head car nous avons terminé l'accès aux variables critiques.
	pthread_mutex_unlock(&mut_listeHead);

	// On debarre le mutex de l'ancien et du nouveau noeuds de queue.
	pthread_mutex_unlock(&tptr->mut_noeudVM);
	pthread_mutex_unlock(&queue->mut_noeudVM);
	pthread_mutex_unlock(&mut_listeQueue);

	// Barre le mutex gerant le nombre de threads.
	sem_wait(&sem_nbThreads);
	nbThreads--;
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	pthread_exit(0);
}

//#######################################
//# Retire un item de la liste chaînée
//# ENTREE: noVM: numéro du noeud a retirer
void removeItem(const int noVM)
{
	struct noeudVM *ptr;
	struct noeudVM *tptr;
	struct noeudVM *optr;
	// Barre le mutex gerant le nombre de remove en cours.
	pthread_mutex_lock(&mut_nbRemove);
	nbRemove++;
	pthread_mutex_unlock(&mut_nbRemove);

	nbThreads++; // Incrémentation du nombre de threads courant de l'application.
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	// Empecher de retirer le noeud si un operation (autre que remove) est en cours d'execution
	while (1)
	{
		sem_wait(&sem_nbThreads);
		pthread_mutex_lock(&mut_nbRemove);

		if (nbThreads <= nbRemove)
		{
			sem_post(&sem_nbThreads);
			pthread_mutex_unlock(&mut_nbRemove);
			break;
		}
		sem_post(&sem_nbThreads);
		pthread_mutex_unlock(&mut_nbRemove);
	}

	// Vérification sommaire (noVM>0 et liste non vide)
	if ((noVM < 1) || (isListEmpty() != 0))
	{
		// Barre le mutex gerant le nombre de threads.
		sem_wait(&sem_nbThreads);
		nbThreads--;
		// Debarre le mutex gerant le nombre de threads.
		sem_post(&sem_nbThreads);

		// Barre le mutex gerant le nombre de remove.
		pthread_mutex_lock(&mut_nbRemove);
		nbRemove--;
		// Debarre le mutex gerant le nombre de remove.
		pthread_mutex_unlock(&mut_nbRemove);
		pthread_exit(0);
	}

	// Pointeur de recherche
	if (noVM == 1)
	{
		// On barre le mutex de la head de la liste.
		pthread_mutex_lock(&mut_listeHead);

		ptr = head; // suppression du premier element de la liste

		// On debarre le mutex de la head de la liste.
		pthread_mutex_unlock(&mut_listeHead);
	}
	else
	{
		ptr = findPrev(noVM);
	}
	// L'item a été trouvé
	if (ptr != NULL)
	{

		nbVM--;

		// Memorisation du pointeur de l'item en cours de suppression
		// Ajustement des pointeurs

		// On barre le mutex de la head et queue de la liste.
		pthread_mutex_lock(&mut_listeHead);
		pthread_mutex_lock(&mut_listeQueue);

		if ((head == ptr) && (noVM == 1)) // suppression de l'element de tete
		{
			if (head == queue) // un seul element dans la liste
			{
				// On detruit le mutex sur le noeud de la VM
				pthread_mutex_destroy(&(ptr->mut_noeudVM));

				free(ptr->VM.ptrDebutVM);
				free(ptr);
				queue = head = NULL;

				// On debarre le mutex de la head et queue de la liste.
				pthread_mutex_unlock(&mut_listeHead);
				pthread_mutex_unlock(&mut_listeQueue);

				// Barre le mutex gerant le nombre de threads.
				sem_wait(&sem_nbThreads);
				nbThreads--;
				// Debarre le mutex gerant le nombre de threads.
				sem_post(&sem_nbThreads);

				// Barre le mutex gerant le nombre de remove.
				pthread_mutex_lock(&mut_nbRemove);
				nbRemove--;
				// Debarre le mutex gerant le nombre de remove.
				pthread_mutex_unlock(&mut_nbRemove);
				pthread_exit(0);
			}
			tptr = ptr->suivant;
			head = tptr;

			// On detruit le mutex sur le noeud de la VM
			pthread_mutex_destroy(&(ptr->mut_noeudVM));
			free(ptr->VM.ptrDebutVM);
			free(ptr);

			// On debarre le mutex de la head et queue de la liste.
			pthread_mutex_unlock(&mut_listeHead);
			pthread_mutex_unlock(&mut_listeQueue);
		}
		else if (queue == ptr->suivant) // suppression de l'element de queue
		{
			// On detruit le mutex sur le noeud (queue) de la VM
			pthread_mutex_destroy(&(queue->mut_noeudVM));

			queue = ptr;
			free(ptr->suivant->VM.ptrDebutVM);
			free(ptr->suivant);
			ptr->suivant = NULL;

			// On debarre le mutex de la head et queue de la liste.
			pthread_mutex_unlock(&mut_listeHead);
			pthread_mutex_unlock(&mut_listeQueue);

			// Barre le mutex gerant le nombre de threads.
			sem_wait(&sem_nbThreads);
			nbThreads--;
			// Debarre le mutex gerant le nombre de threads.
			sem_post(&sem_nbThreads);

			// Barre le mutex gerant le nombre de remove.
			pthread_mutex_lock(&mut_nbRemove);
			nbRemove--;
			// Debarre le mutex gerant le nombre de remove.
			pthread_mutex_unlock(&mut_nbRemove);
			pthread_exit(0);
		}
		else // suppression d'un element dans la liste
		{
			optr = ptr->suivant;
			ptr->suivant = ptr->suivant->suivant;
			tptr = ptr->suivant;

			// On detruit le mutex sur le noeud de la VM
			pthread_mutex_destroy(&(queue->mut_noeudVM));
			free(optr->VM.ptrDebutVM);
			free(optr);

			// On debarre le mutex de la head et queue de la liste.
			pthread_mutex_unlock(&mut_listeHead);
			pthread_mutex_unlock(&mut_listeQueue);
		}

		while (tptr != NULL)
		{ // ajustement des numeros de VM

			// Est-ce le prédécesseur de l'item recherché?
			tptr->VM.noVM--;
			// On retourne un pointeur sur l'item précédent

			// Déplacement du pointeur de navigation
			tptr = tptr->suivant;
		}
	}
	int sem_nbThreads_val = 0;
	sem_getvalue(&sem_nbThreads, &sem_nbThreads_val);
	// printf("Finished remove current sem_nbThreads = %d\n", sem_nbThreads_val);
	sem_wait(&sem_nbThreads);
	nbThreads--;
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	pthread_mutex_lock(&mut_nbRemove);
	nbRemove--;
	// Debarre le mutex gerant le nombre de remove.
	pthread_mutex_unlock(&mut_nbRemove);
	pthread_exit(0);
}

//#######################################
//#
//# Affiche les items dont le numéro séquentiel est compris dans une plage
//#
void listItems(const struct listItemsArgs *args)
{
	char feedback[200];
	
	nbThreads++; // Incrémentation du nombre de threads courant de l'application.
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	// msleep(1000);

	// On barre le mutex head de la liste.
	pthread_mutex_lock(&mut_listeHead);

	struct noeudVM *ptr = head; // premier element

	if (ptr != NULL)
	{
		// On barre le mutex sur le noeud de la VM de tête
		pthread_mutex_lock(&head->mut_noeudVM);
	}

	// On debarre le mutex head de la liste.
	pthread_mutex_unlock(&mut_listeHead);

	// On barre l'accès à la console.
	sem_wait(&sem_consoleAccess);

	// Affichage des entêtes de colonnes
	sprintf(feedback, "noVM  Busy?		Adresse Debut VM                        \n");
	sprintf(feedback, "========================================================\n");

	while (ptr != NULL)
	{

		// L'item a un numéro séquentiel dans l'interval défini
		if ((ptr->VM.noVM >= args->start) && (ptr->VM.noVM <= args->end))
		{
			sprintf(feedback, "%d \t %d \t %p\n",
				   ptr->VM.noVM,
				   ptr->VM.busy, ptr->VM.ptrDebutVM);
		}
		if (ptr->VM.noVM > args->end)
		{
			// Fini de lister les éléments demandés alors on peut unlock le noeud de la VM.
			pthread_mutex_unlock(&(ptr->mut_noeudVM));
			// L'ensemble des items potentiels sont maintenant passés
			// Déplacement immédiatement à la FIN de la liste
			// Notez que le pointeur optr est toujours valide
			ptr = NULL;
		}
		else
		{
			struct noeudVM *ancienNoeud = ptr;
			if (ptr->suivant != NULL)
			{
				pthread_mutex_lock(&(ptr->suivant->mut_noeudVM));
			}
			ptr = ptr->suivant;

			// On debarre l'ancien noeud.
			pthread_mutex_unlock(&(ancienNoeud->mut_noeudVM));
		}
	}

	// Affichage des pieds de colonnes
	sprintf(feedback, "========================================================\n\n");
	
	sendFeedback(feedback);

	// On debarre l'accès à la console.
	sem_post(&sem_consoleAccess);
	// Barre le mutex gerant le nombre de threads.
	sem_wait(&sem_nbThreads);
	nbThreads--;
	// Debarre le mutex gerant le nombre de threads.
	sem_post(&sem_nbThreads);

	pthread_exit(0);
}

//#######################################
//#
//# Verifie si la liste est vide en exclusion mutuelle et retourne un int indiquant le resultat de la vérification.
//#
int isListEmpty()
{

	// On barre le mutex de la tête et de la queue de la liste.
	pthread_mutex_lock(&mut_listeQueue);
	pthread_mutex_lock(&mut_listeHead);
	// La liste est vide
	if ((head == NULL) && (queue == NULL))
	{
		// On débarre le mutex de la tête et de la queue de la liste.car nous avons terminé l'accès aux variables critiques.
		pthread_mutex_unlock(&mut_listeQueue);
		pthread_mutex_unlock(&mut_listeHead);
		return 1;
	}

	// On débarre le mutex de la tête et de la queue de la liste.car nous avons terminé l'accès aux variables critiques.
	pthread_mutex_unlock(&mut_listeQueue);
	pthread_mutex_unlock(&mut_listeHead);
	return 0;
}
