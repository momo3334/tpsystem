//#########################################################
//#
//# Titre : 	UTILITAIRES (MAIN) TP1 LINUX Automne 21
//#				SIF-1015 - Système d'exploitation
//#				Université du Québec à Trois-Rivières
//#
//# Auteur : 	Francois Meunier
//#	Date :		Septembre 2022
//#
//# Langage : 	ANSI C on LINUX
//#
//#######################################

#include "gestionListeChaineeVMS.h"
#include "gestionVMS.h"
#include <errno.h>

#define NUM_THREADS 1000

#define ERROR_HANDLER(en, msg) \
	do                         \
	{                          \
		errno = en;            \
		perror(msg);           \
		exit(EXIT_FAILURE);    \
	} while (0)

// Pointeur de tête de liste
struct noeud *head;
// Pointeur de queue de liste pour ajout rapide
struct noeud *queue;
// nombre de VM actives
int nbVM;

// Array contenant tout les threads du programme.
struct pthread_t_with_success threads[NUM_THREADS];

// Compteur gardant en mémoire le nombre courant de thread de l'application.
int nbThreads;

// Compteur gardant en mémoire le nombre courant de remove de l'application.
int nbRemove;

// Semaphore permettant de gerer l'accès au nombre de thread courant de l'application.
sem_t sem_nbThreads;

// Mutex permettant de gerer l'accès au nombre de remove en attente courant de l'application.
pthread_mutex_t mut_nbRemove;

// Mutex permettant de gerer l'accès au système de fichier pour tous les threads de l'application.
pthread_mutex_t mut_fileSystemAccess;

// Semaphore permettant de gerer l'accès à la console pour tous les threads de l'application.
sem_t sem_consoleAccess;

// Mutex empechant l'accès concurrentiel au différents noeuds de la liste chaînée
pthread_mutex_t mut_listeHead, mut_listeQueue, mut_listeNbVM;

int main(int argc, char *argv[])
{

	// Initialisation des pointeurs
	head = NULL;
	queue = NULL;
	nbVM = 0;
	nbRemove = 0;
	nbThreads = 0;

	// Initialisation des mutex
	pthread_mutexattr_t nbThreadsAttr;
	int ret = 0;
	pthread_mutexattr_init(&nbThreadsAttr);
	ret = pthread_mutexattr_settype(&nbThreadsAttr, PTHREAD_MUTEX_ERRORCHECK);
	if (ret)
		ERROR_HANDLER(ret, "pthread_mutexattr_settype");

	// pthread_mutex_init(&mut_nbThreads, &nbThreadsAttr);

	pthread_mutex_init(&mut_fileSystemAccess, NULL);
	pthread_mutex_init(&mut_listeHead, NULL);
	pthread_mutex_init(&mut_listeQueue, NULL);
	pthread_mutex_init(&mut_listeNbVM, NULL);
	pthread_mutex_init(&mut_nbRemove, NULL);

	// Initialisation des semaphore
	sem_init(&sem_consoleAccess, 0, 1);
	sem_init(&sem_nbThreads, 0, 1);

	//"Nettoyage" de la fenêtre console
	// cls();

	 // Création du server de transaction.
    createTransactionServer();
    printf("Transaction server successfully started! \n Listening...");

	// Attends que tous les threads enfant termine leur éxécution avant de terminer le programme principal.
	for (int i = 0; i < NUM_THREADS; i++)
		if (threads[i].isSuccessfullyStarted == 0)
		{
			pthread_join(threads[i].thread, NULL);
		}
	return 0;

	// Attendre la fin du thread serveur

	// Deinitialisation des mutex
	// pthread_mutex_destroy(&mut_nbThreads);
	pthread_mutex_destroy(&mut_fileSystemAccess);
	pthread_mutex_destroy(&mut_listeHead);
	pthread_mutex_destroy(&mut_listeQueue);
	pthread_mutex_destroy(&mut_listeNbVM);
	pthread_mutex_destroy(&mut_nbRemove);

	// Deinitialisation des semaphores
	sem_destroy(&sem_consoleAccess);
	sem_destroy(&sem_nbThreads);

	// Fin du programme
	exit(0);
}
