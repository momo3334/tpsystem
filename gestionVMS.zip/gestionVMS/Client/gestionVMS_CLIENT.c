#include "../gestionListeChaineeVMS.h"
#include "./gestionVMS_CLIENT.h"
#define ls ACS_VLINE
#define bs ACS_HLINE

int main(int argc, char *argv[])
{
    WINDOW *fen1, *transmetteur1;
    int server_fifo_fd, client_fifo_fd;
    char *input_command = malloc(sizeof(char[200]));
    char *input_command_history = malloc(sizeof(char[2000]));
    int input_char;

    server_fifo_fd = open(SERVER_FIFO_NAME, O_WRONLY);

    // Creating the window
    initscr();

    int ligne = 15, colonne = 55;
    fen1 = newwin(ligne, colonne, 0, 0); // Cree une fenetre de 15 lignes,
    box(fen1, ls, bs);                   /* creation de la bordure */
    mvwaddstr(fen1, 0, colonne / 4, " USER 1 - Transmission ");
    wrefresh(fen1);
    cbreak();
    noecho();

    // Getting user input
    int c = mvwgetch(fen1, 1, 1);
    flushinp();
    int i = 0;

    while (strcmp(input_command, "exit"))
    {
        if (c != 2 && c != 10 && c != '\n' && c != 127)
        {
            append(input_command, (char)c);
            i++;
        }
        else if (c == 127 && i > 0)
        {
            mvwaddch(fen1, 1, i, ' ');
            i--;
            pop(input_command);
        }

        if (c == '\n')
        {
            // Send command to server
            send_command(input_command, server_fifo_fd);

            // Reset cursor and line
            i = 0;
            for (int p = 1; p < strlen(input_command) + 1; p++)
            {
                mvwaddch(fen1, 1, p, ' ');
            }
            wrefresh(fen1);

            // Append to command history
            if (strlen(input_command_history) > 0)
            {
                append(input_command_history, (char)31); // Add separator
            }
            strcat(input_command_history, input_command);   // Append command to command history
            memset(input_command, 0, sizeof input_command); // empty buffer

            // Display history command underneath
            char *token, *str, *tofree;
            int j = 2;
            tofree = str = strdup(input_command_history); // We own str's memory now.
            while ((token = strsep(&str, "\x1F")))
                mvwaddstr(fen1, j++, 1, token);
            free(tofree);
        }
        else
        {
            mvwaddstr(fen1, 1, 1, input_command);
        }
        // mvwprintw(fen1, 7, 1, "%d", c);
        // mvwprintw(fen1, 8, 1, "%d", i);

        wmove(fen1, 1, i + 1);

        // Getting the next character
        c = wgetch(fen1);
    }

    // mvwaddstr(fen1, 3, 1, input_command);
    wrefresh(fen1);

    // creer_fenetreTxD1(fen1, transmetteur1);
    //  sleep(10);
    //   server_fifo_fd = open(SERVER_FIFO_NAME, O_WRONLY);
    //  printf("opened FIFO");

    // if (server_fifo_fd == -1)
    // {
    //     fprintf(stderr, "Sorry, no server\n");
    //     exit(EXIT_FAILURE);
    // }

    // get command
    // get_input(&input_char, fen1);
    // printw("%d %c", input_char, input_char);
    // mvwaddstr(fen1, 1, 1, " USER 1 - Transmission ");
    // wrefresh(fen1);

    // send command

    // printf("Closing fifo");
    close(server_fifo_fd);
    unlink(CLIENT_FIFO_NAME);
    exit(EXIT_SUCCESS);
}

void creer_fenetreTxD1(WINDOW *fen1, WINDOW *transmetteur1)
{

    // wmove(fen1, 1, 1);

    // transmetteur1 = newwin(ligne - 2, colonne - 2, 1, 1); /*Cree une fenetre de 13 lignes,52 colonnes placée à la ligne 1 et colonne 1*/
    // wrefresh(transmetteur1);
    // scrollok(transmetteur1, 1); /* définition du défilement vertical de la fenêtre */
    // wrefresh(transmetteur1);    /* rafraîchissement de la fenêtre de transmission */
}

void get_input(int *inputk, WINDOW *window)
{

    // printw("%d %c", *input, *input);
    // refresh();
}

void send_command(char *to_send, int server_fifo_fd)
{
    struct Info_FIFO_Transaction info_Transaction;

    info_Transaction.pid_client = getpid();
    strcpy(info_Transaction.transaction, to_send);
    //  sprintf(CLIENT_FIFO_NAME, info_Transaction.pid_client);
    //  if (mkfifo(CLIENT_FIFO_NAME, 0777) == -1)
    //  {
    //      fprintf(stderr, "Sorry, can't make %s\n", CLIENT_FIFO_NAME);
    //  }

    // For each of the five loops, the client data is sent to the server.
    // Then the client FIFO is opened (read-only, blocking mode) and the data read back.
    // Finally, the server FIFO is closed and the client FIFO removed from memory.
    // fprintf(stderr, "beforelloop %s\n", CLIENT_FIFO_NAME);

    // for (times_to_send = 0; times_to_send < 5; times_to_send++)
    // {
    // fprintf(stderr, "lloop %s\n", CLIENT_FIFO_NAME);

    // sprintf(info_Transaction.transaction, "Transaction data: \n pid: %d \n command: %s", info_Transaction.pid_client, info_Transaction.transaction);
    // printf("%d sent %s, ", info_Transaction.pid_client, info_Transaction.transaction);
    write(server_fifo_fd, &info_Transaction, sizeof(info_Transaction));
    // client_fifo_fd = open(CLIENT_FIFO_NAME, O_RDONLY);
    // if (client_fifo_fd != -1)
    //  //{
    //      if (read(client_fifo_fd, &info_Transaction, sizeof(info_Transaction)) > 0)
    //      {
    //          printf("received: %s\n", info_Transaction.transaction);
    //      }
    //      close(client_fifo_fd);
    //  }
    // }
}

void append(char *s, char c)
{
    int len = strlen(s);
    s[len] = c;
    s[len + 1] = '\0';
}

void pop(char *s)
{
    int len = strlen(s);
    if (len > 0)
    {
        s[len - 1] = '\0';
    }
}

char **str_split(char *a_str, const char a_delim)
{
    char **result = 0;
    size_t count = 0;
    char *tmp = a_str;
    char *last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char *) * count);
}