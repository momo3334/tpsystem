void creer_fenetreTxD1(WINDOW *fen1, WINDOW *transmetteur1);
void get_input(int *input, WINDOW *window);
void send_command(char *to_send, int server_fifo_fd);
void append(char *s, char c);
void pop(char *s);
char **str_split(char *a_str, const char a_delim);