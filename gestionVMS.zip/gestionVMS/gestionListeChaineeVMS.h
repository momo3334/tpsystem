#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <pthread.h>

#include <stdint.h>
#include <signal.h>
/* unix */
#include <unistd.h>
#include <fcntl.h>

#include <sys/time.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <curses.h>

#define SERVER_FIFO_NAME "/home/mi262/Desktop/gestionVMS/tmp/FIFO_TRANSACTIONS"
#define CLIENT_FIFO_NAME "/home/mi262/Desktop/gestionVMS/tmp/FIFO_TRANSACTIONS_CLIENT"

struct infoVM
{
	int noVM;
	unsigned char busy;
	uint16_t *ptrDebutVM;
	uint16_t offsetDebutCode; // region memoire ReadOnly
	uint16_t offsetFinCode;
};

struct noeudVM
{
	struct infoVM VM;
	struct noeudVM *suivant;
	pthread_mutex_t mut_noeudVM;
};

// Struct contenant un thread et un int specifiant le succes de sa creation.
struct pthread_t_with_success
{
	pthread_t thread;
	int isSuccessfullyStarted;
};

// Struct contenant les arguments de la fonction removeItem(const int noVM);
struct removeItemArgs
{
	int noVM;
};

// Struct contenant les arguments de la fonction listItems(const int start, const int end);
struct listItemsArgs
{
	int start;
	int end;
};

// Struct contenant les arguments de la fonction executeFile(int noVM, char* sourcefname);
struct executeFileArgs
{
	int noVM;
	char *sourcefname;
};

// Struct contenant les information d'une transaction à effectuer par le serveur
struct Info_FIFO_Transaction
{
	int pid_client;
	char transaction[200];
};

void cls(void);
void error(const int exitcode, const char *message);

struct noeudVM *findItem(const int no);
struct noeudVM *findPrev(const int no);

void addItem();
void removeItem(const int noVM);
void listItems(const struct listItemsArgs *);
void saveItems(const char *sourcefname);
int executeFile(struct executeFileArgs *);
int isListEmpty();
void *readTrans(char *nomFichier);
